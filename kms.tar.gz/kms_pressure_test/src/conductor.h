#ifndef __KPS_CONDUCTOR_H__
#define __KPS_CONDUCTOR_H__

#ifndef WEBRTC_POSIX
#define WEBRTC_POSIX
#endif

#include "webrtc/api/mediastreaminterface.h"
#include "webrtc/api/peerconnectioninterface.h"

//namespace cricket
//{
//	class TurnServer;
//	class StunServer;
//}

class Conductor : public webrtc::PeerConnectionObserver,
	public webrtc::CreateSessionDescriptionObserver,
	public webrtc::SetSessionDescriptionObserver,
	public webrtc::DataChannelObserver
{
public:
	Conductor();
	virtual ~Conductor();

	bool InitializePeerConnection();
	void CreateOffer();
	void OnOfferReply(std::string type, std::string sdp);
	void OnOfferRequest(std::string sdp);
	bool AddIceCandidate(std::string sdp_mid, int sdp_mlineindex, std::string sdp);

	bool ProcessMessages(int delay)
	{
		return rtc::Thread::Current()->ProcessMessages(delay);
	}	

	static std::vector<std::string> GetVideoDevices();
	bool OpenVideoCaptureDevice(std::string &name);
	void AddServerConfig(std::string uri, std::string username, std::string password);

	uint8_t * VideoCapturerI420Buffer()
	{
		if (capturer)
		{
			capturer->PushFrame();
		}
	}

	void CreateDataChannel(const std::string & label);
	void DataChannelSendText(const std::string & text);

protected:
	virtual void webrtc::SetSessionDescriptionObserver::OnSuccess()
	{
		LOG(INFO) << __FUNCTION__;
	}

	virtual void webrtc::CreateSessionDescriptionObserver::OnSuccess(webrtc::SessionDescriptionInterface* desc);
	virtual void OnFailure(const std::string& error);

	virtual void OnAddStream(rtc::scoped_refptr<webrtc::MediaStreamInterface> stream);
	virtual void OnRemoveStream(rtc::scoped_refptr<webrtc::MediaStreamInterface> stream);
	virtual void OnError();
	virtual void OnIceCandidate(const webrtc::IceCandidateInterface* candidate);

	virtual void OnIceChange()
	{
		LOG(INFO) << __FUNCTION__ << " ";
	}

	virtual void OnSignalingChange(webrtc::PeerConnectionInterface::SignalingState state)
	{
		LOG(INFO) << __FUNCTION__ << " " << state;
	}

	virtual void OnIceConnectionChange(webrtc::PeerConnectionInterface::IceConnectionState state)
	{
		LOG(INFO) << __FUNCTION__ << " " << state;
	}

	virtual void OnIceGatheringChange(webrtc::PeerConnectionInterface::IceGatheringState state)
	{
		LOG(INFO) << __FUNCTION__ << " " << state;
	}

	virtual void OnStateChange(webrtc::PeerConnectionObserver::StateType state_changed)
	{
		LOG(INFO) << __FUNCTION__ << " " << state_changed;
	}

	virtual void OnRenegotiationNeeded()
	{
		LOG(INFO) << __FUNCTION__ << " ";
	}

	virtual void OnDataChannel(rtc::scoped_refptr<webrtc::DataChannelInterface> channel);

	virtual void OnStateChange()
	{
		LOG(INFO) << __FUNCTION__;
	}

	virtual void OnMessage(const webrtc::DataBuffer& buffer);

	virtual void OnBufferedAmountChange(uint64_t previous_amount)
	{
		LOG(INFO) << __FUNCTION__;
	}

	int AddRef() const
	{
		return 0;
	};
	int Release() const
	{
		return 0;
	};

private:

	bool CreatePeerConnection(bool dtls);
	void DeletePeerConnection();
	void AddStreams();        

	rtc::scoped_refptr<webrtc::PeerConnectionInterface> peer_connection_;
	rtc::scoped_refptr<webrtc::PeerConnectionFactoryInterface> pc_factory_;
	std::map<std::string, rtc::scoped_refptr<webrtc::MediaStreamInterface>> active_streams_;
	rtc::scoped_refptr<webrtc::DataChannelInterface> data_channel;
	std::vector<webrtc::PeerConnectionInterface::IceServer> serverConfigs;

	YuvFramesCapturer2 * capturer;
	cricket::VideoCapturer * capturer_internal;

	std::unique_ptr<VideoRenderer> local_video;
	std::unique_ptr<VideoRenderer> remote_video;
	std::unique_ptr<AudioRenderer> remote_audio;

public:
	int caputureFps;
	bool audioEnabled;
	bool barcodeEnabled;

	int width_;
	int height_;
};
#endif //__KPS_CONDUCTOR_H__
